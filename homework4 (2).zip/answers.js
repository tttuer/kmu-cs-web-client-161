function answer_1() {
  document.getElementById("q1-answer").innerHTML = "<ul><li>D - Document</li><li>O - Object</li><li>M - Model</li></ul>";
}

function answer_2() {
    document.getElementById("q2-answer").innerHTML = "<ul><li>Represent HTML file as an object so that Javascript can easily access</li><li>Represented in a tree structure where the html tag is the root</li></ul>";
}

function answer_3() {
    var t = document.getElementsByClassName("q34-answer");
    t[0].innerHTML = "<ul><li>Parent node : a node directly above a node</li><li>child node : nodes one level directly below</li><li>sibling node : nodes at the same level(same parent node)</li><li>descendant nodes : a set of nodes any number of levels below another node</li><li>ancestor nodes : a set of nodes above a node in a tree</li></ul>";
}

function answer_4() {
    var t = document.getElementsByClassName("q34-answer");
    t[1].innerHTML = "<ul><li>document.getElementById(id_name) : returns an element with a given id_name and duplicate id is not allowed in th HTML specification so one element can be returned</li><li>document.getElementsByClassName(class_name) : get a list of elements based on the class name and mutiple elements can be returned</li><li>document.getElementsByName() : get a list of elements based on the name and multiple elements can be returned</li><li>document.getElementsByTagName() : get a list of elements with the input tag name and multiple elements can be returned</li></ul>";
}

$('a').click(function(){
    output="Answer5";
    $(this).text(output);
})

$('.item').click(function(){
    $(this).attr('style','font-size:3em')
})

$('span').removeClass('demo');
$('.demo').dblclick(function(){
    $(this).attr('style','color:blue');
})