console.log("hello homework3")

function stringToInt(input){
    var a=parseInt(input);
    var b=1;
    
    if(typeof(a)==typeof(b))
        return a;
    else
        console.log("NaN");
}

function maskNumber(input){
    var a=input.substring(0,7);
    var b="****";
    var mask_number=a.concat(b);
    
    return mask_number;
}

function getAverage(input_array){
    var sum=0;
    var len=input_array.length;
    var i=0;
    
    while(i<len){
        sum+=input_array[i++];
    }
    
    var avg=sum/len;
    
    return avg;
}

function isMultipleSeven(input){
    if(input%7===0)
        return true;
    else
        return false;
}

function operation(type,input1,input2){
    if(type=="add"){
        return input1+input2;
    }
    else if(type=="substract"){
        return input1-input2;
    }
    else if(type=="multiply"){
        return input1*input2;
    }
    else if(type=="divide"){
        return input1/input2;
    }
    else
        console.log("Not Supported");
}

function triangleMtn(input){
    var i;
    var j;
    var arr;
    
    for(i=0;i<input;i++){
        arr="";
        for(j=0;j<=i;j++){
            arr+="*";
        }
        console.log(arr);
    }
    return ;
}